var firebaseConfig = {
    apiKey: "AIzaSyBr8YOyPE2eqFlFMy20LvMLC5Ybhssa6L4",
    authDomain: "dev20chat-27d3f.firebaseapp.com",
    databaseURL: "https://dev20chat-27d3f-default-rtdb.firebaseio.com/",
    projectId: "dev20chat-27d3f",
    storageBucket: "dev20chat-27d3f.appspot.com",
    messagingSenderId: "284246193595",
    appId: "1:284246193595:web:74c9bd1e3a36257803809e"
  };